package com.example.ukmthrift.screens.products

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ukmthrift.repository.Product
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProductsViewModel @Inject constructor(private val firebaseRepo: Product) :
    ViewModel() {

    var categoryList = MutableLiveData<List<Product>>()
    var path = firebaseRepo.path

    private val _isLoading = firebaseRepo.isLoading
    val isLoading: LiveData<Boolean> = _isLoading


    fun getProduct(path: String) = viewModelScope.launch {
        categoryList.value = firebaseRepo.getProductRealtime(path)
    }
}