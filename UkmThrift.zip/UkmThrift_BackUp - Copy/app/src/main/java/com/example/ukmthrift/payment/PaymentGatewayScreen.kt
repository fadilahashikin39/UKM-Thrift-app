package com.example.ukmthrift.payment

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.ukmthrift.R
import kotlinx.coroutines.delay

@Composable
fun PaymentGatewayScreen(navController: NavController) {
    var processing by remember { mutableStateOf(true) }

    // Simulate a delay for processing the payment
    LaunchedEffect(Unit) {
        delay(3000)
        processing = false
        navController.navigate("order_confirmed")
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Bank Logo
            Image(
                painter = painterResource(id = R.drawable.rhb_logo), // Replace with your bank logo drawable
                contentDescription = "RHB Bank Logo",
                modifier = Modifier.size(200.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Loading Indicator
            if (processing) {
                CircularProgressIndicator(
                    color = Color.Black, // Customize the color as needed
                    strokeWidth = 4.dp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Status Text
            Text(
                text = if (processing) "Processing your payment..." else "Redirecting...",
                fontSize = 18.sp,
                color = Color.DarkGray
            )
        }
    }
}