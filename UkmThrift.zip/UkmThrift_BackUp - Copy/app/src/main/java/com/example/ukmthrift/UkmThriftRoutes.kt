package com.example.ukmthrift

const val SPLASH_SCREEN = "SplashScreen"
const val LOGIN_SCREEN = "LoginScreen"
const val SIGN_UP_SCREEN = "SignUpScreen"
const val HOME_SCREEN = "HomeScreen"
const val ADD_PRODUCT_SCREEN = "AddProductScreen"
const val CATEGORY_SCREEN = "CategoryScreen"
const val BASKET_SCREEN= "BasketScreen"

const val TASK_ID = "taskId"
const val TASK_ID_ARG = "?$TASK_ID={$TASK_ID}"