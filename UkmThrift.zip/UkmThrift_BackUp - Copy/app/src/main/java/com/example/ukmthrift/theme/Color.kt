package com.example.ukmthrift.theme

import androidx.compose.ui.graphics.Color

// Light theme
val md_theme_light_primary = Color( 0xFF3E4A28) // Olive Green
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_primaryContainer = Color(0xFFD9E4B5) // Light Olive
val md_theme_light_onPrimaryContainer = Color(0xFF6B8E23)
val md_theme_light_secondary = Color(0xFF98C79D) // Soft Sage Green
val md_theme_light_onSecondary = Color(0xFFFFFFFF)
val md_theme_light_secondaryContainer = Color(0xFFD1E8D6)
val md_theme_light_onSecondaryContainer = Color(0xFF4C6B4F)
val md_theme_light_tertiary = Color(0xFF8F9F88) // Muted Green
val md_theme_light_onTertiary = Color(0xFFFFFFFF)
val md_theme_light_tertiaryContainer = Color(0xFFD3E3C5)
val md_theme_light_onTertiaryContainer = Color(0xFF4A5B40)
val md_theme_light_error = Color(0xFFB71C1C) // Dark Red
val md_theme_light_errorContainer = Color(0xFFF2C2C2)
val md_theme_light_onError = Color(0xFFFFFFFF)
val md_theme_light_onErrorContainer = Color(0xFF660000)
val md_theme_light_background = Color(0xFFF4F8F1) // Very Light Green
val md_theme_light_onBackground = Color(0xFF3B3B3B)
val md_theme_light_surface = Color(0xFFFFFFFF)
val md_theme_light_onSurface = Color(0xFF3B3B3B)
val md_theme_light_surfaceVariant = Color(0xFFD0D9D2)
val md_theme_light_onSurfaceVariant = Color(0xFF4A4D47)
val md_theme_light_outline = Color(0xFF6D7A6A)
val md_theme_light_inverseOnSurface = Color(0xFFF4F8F1)
val md_theme_light_inverseSurface = Color(0xFF3B3B3B)
val md_theme_light_inversePrimary = Color(0xFF6B8E23)
val md_theme_light_surfaceTint = Color(0xFF6B8E23)
val md_theme_light_outlineVariant = Color(0xFF6D7A6A)
val md_theme_light_scrim = Color(0xFF000000)

// Dark theme
val md_theme_dark_primary = Color(0xFF4B6F1D) // Dark Olive Green
val md_theme_dark_onPrimary = Color(0xFFFFFFFF)
val md_theme_dark_primaryContainer = Color(0xFF6B8E23) // Olive Green
val md_theme_dark_onPrimaryContainer = Color(0xFFD9E4B5)
val md_theme_dark_secondary = Color(0xFF5C7A5C) // Darker Sage Green
val md_theme_dark_onSecondary = Color(0xFFFFFFFF)
val md_theme_dark_secondaryContainer = Color(0xFF3A4D39)
val md_theme_dark_onSecondaryContainer = Color(0xFFD1E8D6)
val md_theme_dark_tertiary = Color(0xFF707C5A) // Muted Olive Green
val md_theme_dark_onTertiary = Color(0xFFFFFFFF)
val md_theme_dark_tertiaryContainer = Color(0xFF4E5A44)
val md_theme_dark_onTertiaryContainer = Color(0xFFD3E3C5)
val md_theme_dark_error = Color(0xFFB71C1C)
val md_theme_dark_errorContainer = Color(0xFFF2C2C2)
val md_theme_dark_onError = Color(0xFFFFFFFF)
val md_theme_dark_onErrorContainer = Color(0xFF660000)
val md_theme_dark_background = Color(0xFF3B3B3B) // Dark Greyish Green
val md_theme_dark_onBackground = Color(0xFFF4F8F1)
val md_theme_dark_surface = Color(0xFF3B3B3B)
val md_theme_dark_onSurface = Color(0xFFF4F8F1)
val md_theme_dark_surfaceVariant = Color(0xFF4A4D47)
val md_theme_dark_onSurfaceVariant = Color(0xFFD0D9D2)
val md_theme_dark_outline = Color(0xFF6D7A6A)
val md_theme_dark_inverseOnSurface = Color(0xFF3B3B3B)
val md_theme_dark_inverseSurface = Color(0xFFF4F8F1)
val md_theme_dark_inversePrimary = Color(0xFF4B6F1D)
val md_theme_dark_surfaceTint = Color(0xFF4B6F1D)
val md_theme_dark_outlineVariant = Color(0xFF6D7A6A)
