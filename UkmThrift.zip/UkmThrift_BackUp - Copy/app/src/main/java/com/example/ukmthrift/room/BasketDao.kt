package com.example.ukmthrift.room

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.ukmthrift.model.Basket

@Dao
interface BasketDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addToBasket(basket: Basket)

    @Query("SELECT * FROM basket_table ORDER BY basket_id ASC")
    fun readAllBasket(): LiveData<List<Basket>>

    @Query("DELETE FROM basket_table WHERE uuid = :idInput")
    suspend fun deleteFromBasket(idInput: String)

    @Query("SELECT SUM(count * basket_price) FROM basket_table")
    suspend fun getTotalPrice(): Double

    @Update
    suspend fun updateBasket(basket: Basket) // For count in adapter
}