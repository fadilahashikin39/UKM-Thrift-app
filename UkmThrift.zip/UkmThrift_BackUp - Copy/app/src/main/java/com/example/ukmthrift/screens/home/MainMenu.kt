package com.example.ukmthrift.screens.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ukmthrift.R
import com.example.ukmthrift.theme.UkmThriftTheme

// Define the custom font
val queensmoothieFontFamily = FontFamily(
    Font(R.font.queensmoothie1) // Reference to the font file in res/font
)

@Composable
fun MainMenu(
    onSellClicked: () -> Unit,
    onDonateClicked: () -> Unit,
    onBuyClicked: () -> Unit,
    onExitProgramClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
    ) {
        // Background image
        Image(
            painter = painterResource(id = R.drawable.welcome_thrift), // Background resource
            contentDescription = "Background Image",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Foreground content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 16.dp, top = 8.dp, end = 16.dp) // Adjusted top padding to move content up
            ,
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Significantly enlarged logo image
            Image(
                painter = painterResource(id = R.drawable.logo_thrift), // Logo resource
                contentDescription = "UKM Thrift Logo",
                modifier = Modifier
                    .size(200.dp)
                    .padding(bottom = 24.dp)
            )

            Text(
                text = "Welcome to UKM Thrift",
                fontSize = 35.sp,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = queensmoothieFontFamily // Use local font family
                ),
                modifier = Modifier.padding(bottom = 24.dp)
            )


            Button(
                onClick = onSellClicked,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text("Sell")
            }

            Button(
                onClick = onDonateClicked,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text("Donate")
            }

            Button(
                onClick = onBuyClicked,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text("Buy")
            }

            Button(
                onClick = onExitProgramClicked,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
            ) {
                Text("Exit")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainMenuPreview() {
    UkmThriftTheme {
        MainMenu(
            onSellClicked = { println("Sell clicked") },
            onDonateClicked = { println("Donate clicked") },
            onBuyClicked = { println("Buy clicked") },
            onExitProgramClicked = { println("Exit clicked") }
        )
    }
}
