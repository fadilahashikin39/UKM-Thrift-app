package com.example.ukmthrift.screens.basket

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ukmthrift.R
import com.example.ukmthrift.utils.extension.showErrorSnackBar
import com.example.ukmthrift.utils.extension.visible
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BasketFragment : Fragment() {
    private val viewModel: BasketViewModel by viewModels()
    private val adapter by lazy {
        BasketAdapter(
            onRemoveBasketClick = ::onRemoveBasketClick,
            viewModel::increase,
            viewModel::decrease
        )
    }

    private lateinit var rvBasket: RecyclerView
    private lateinit var tvBasketEmpty: TextView
    private lateinit var btnCheckout: Button
    private lateinit var tvAmount: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Creating the root view for the fragment programmatically
        val rootView =
            ViewGroup.inflate(requireContext(), android.R.layout.simple_list_item_1, null)

        // Programmatically creating the layout
        rvBasket = RecyclerView(requireContext()).apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@BasketFragment.adapter
        }

        tvBasketEmpty = TextView(requireContext()).apply {
            text = getString(R.string.empty_basket)
            gravity = Gravity.CENTER
            visibility = View.GONE
        }

        btnCheckout = Button(requireContext()).apply {
            text = getString(R.string.checkout)
        }

        tvAmount = TextView(requireContext()).apply {
            text = getString(R.string._0_TL)
        }

        // Adding views to root container
        val container = rootView as ViewGroup
        container.addView(rvBasket)
        container.addView(tvBasketEmpty)
        container.addView(tvAmount)
        container.addView(btnCheckout)

        return rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initializeObserver()
    }

    private fun onRemoveBasketClick(s: String) {
        viewModel.deleteFromBasket(s)
        viewModel.resetTotalAmount()
    }

    @SuppressLint("StringFormatInvalid")
    private fun initializeObserver() {
        viewModel.apply {
            readAllBasket.observe(viewLifecycleOwner) { basketList ->

                totalBasket()
                adapter.submitList(basketList)

                if (basketList.isEmpty()) {
                    tvBasketEmpty.visible()
                }

                btnCheckout.setOnClickListener {
                    // Check if the basket is not empty and total amount is available
                    if (basketList.isNotEmpty()) {
                        val total = totalAmount.value
                        if (total != null && total > 0) {
                            // Ensure the amount is valid before navigating
                            val action =
                                BasketFragmentDirections.actionBasketFragmentToPaymentFragment(total.toFloat())
                            Navigation.findNavController(it).navigate(action)
                        } else {
                            // Show error if the total amount is zero or invalid
                            requireView().showErrorSnackBar(
                                getString(R.string.error_invalid_amount),
                                true
                            )
                        }
                    } else {
                        // Show an error if the basket is empty
                        requireView().showErrorSnackBar(getString(R.string.empty_bag), true)
                    }
                }

                totalAmount.observe(viewLifecycleOwner) { amount ->
                    // Safely handle null values and format the amount for display
                    tvAmount.text = if (amount != null && amount > 0) {
                        getString(R.string.total_tl, amount.toString())
                    } else {
                        getString(R.string._0_TL)
                    }
                }

            }
        }
    }
}
