package com.example.ukmthrift.screens.basket

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ukmthrift.model.Basket
import com.example.ukmthrift.repository.Product
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BasketViewModel @Inject constructor(private val repository: Product) : ViewModel() {
    val readAllBasket: LiveData<List<Basket>> = repository.readAllBasket

    private val _totalAmount = MutableLiveData(0.0)
    val totalAmount: LiveData<Double> = _totalAmount

    fun deleteFromBasket(basketId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteFromBasket(basketId)
        }
    }

    private fun updateBasket(product: Basket) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateBasket(product)
        }
    }


    fun increase(product: Basket) {
        _totalAmount.value = _totalAmount.value?.plus(product.productPrice)
        updateBasket(product)
    }

    fun decrease(product: Basket) {
        _totalAmount.value = _totalAmount.value?.minus(product.productPrice)
        updateBasket(product)
    }

    fun resetTotalAmount() {
        _totalAmount.value = 0.0
    }

    fun totalBasket() {
        viewModelScope.launch() {
            _totalAmount.value = repository.totalBasket()
        }
    }
}