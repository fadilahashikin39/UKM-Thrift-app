package com.example.ukmthrift.model

data class Category(
    val categoryName: String,
    val categoryImage: Int
)