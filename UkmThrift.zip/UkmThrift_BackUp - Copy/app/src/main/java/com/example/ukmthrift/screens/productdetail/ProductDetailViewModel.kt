package com.example.ukmthrift.screens.productdetail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ukmthrift.model.Basket
import com.example.ukmthrift.repository.Product
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProductDetailViewModel @Inject constructor(private val repository: Product) :
    ViewModel() {


    fun addToBasket(basket: Basket) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addToBasket(basket)
        }
    }

}