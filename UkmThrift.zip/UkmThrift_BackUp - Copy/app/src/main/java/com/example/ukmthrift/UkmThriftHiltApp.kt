package com.example.ukmthrift

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp class MakeItSoHiltApp : Application() {}