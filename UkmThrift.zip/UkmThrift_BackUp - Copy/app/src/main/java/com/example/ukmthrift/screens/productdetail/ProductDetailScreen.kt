package com.example.ukmthrift.screens.productdetail

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.example.ukmthrift.R
import com.example.ukmthrift.databinding.FragmentProductDetailBinding
import com.example.ukmthrift.delegate.viewBinding
import com.example.ukmthrift.model.Basket
import com.example.ukmthrift.utils.extension.back
import com.example.ukmthrift.utils.extension.showErrorSnackBar
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ProductDetailScreen : Fragment(R.layout.fragment_product_detail) {

    private val binding by viewBinding(FragmentProductDetailBinding::bind)
    private val viewModel: ProductDetailViewModel by viewModels()
    private val args: ProductDetailScreenArgs by navArgs()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val product = args.objectProduct

        shareLink()

        with(binding) {
            tvDetailName.text = product.productTitle
            tvDetailInfo.text = product.productDescription
            tvDetailPrice.text = getString(R.string.total_tl, product.productPrice)

            Glide.with(this@ProductDetailScreen).load(product.img)
                .into(binding.ivProductImage)

            // Back button
            ibArrowBack.setOnClickListener {
                Navigation.back(it)
            }

            // Add to Basket
            btnAddToBasket.setOnClickListener {
                viewModel.addToBasket(
                    Basket(
                        id = product.id,
                        productId = product.id!!,
                        img = product.img!!,
                        productTitle = product.productTitle!!,
                        productPrice = product.productPrice!!.toInt(),
                        productCount = product.productCount!!
                    )
                )
                requireView().showErrorSnackBar(getString(R.string.product_add), false)
            }
        }
    }

    private fun shareLink() {
        binding.btnDetailShare.setOnClickListener {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, binding.webView.url)
                startActivity(Intent.createChooser(this, getString(R.string.share_link)))
            }
        }
    }
}
