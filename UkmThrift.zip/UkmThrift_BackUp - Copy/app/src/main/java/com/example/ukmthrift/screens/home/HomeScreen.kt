package com.example.ukmthrift.screens.home

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.example.ukmthrift.R
import com.example.ukmthrift.databinding.FragmentHomeBinding
import com.example.ukmthrift.delegate.viewBinding
import com.example.ukmthrift.model.Category
import com.example.ukmthrift.utils.extension.sent

class Home : Fragment(R.layout.fragment_home) {
    private val binding by viewBinding(FragmentHomeBinding::bind)
    private val category by lazy { Category(onClickCategory = ::onClickCategory) }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvAddStyle.setOnClickListener {
            Navigation.sent(it, R.id.action_homeFragment_to_addProductFragment)
        }

        val categoryList = arrayListOf<Category>()
        val woman = Category(
            getString(R.string.woman),
            R.drawable.woman2
        )
        val man = Category(
            getString(R.string.man),
            R.drawable.man
        )
        val child = Category(
            getString(R.string.child),
            R.drawable.child
        )
        categoryList.add(woman)
        categoryList.add(man)
        categoryList.add(child)
        category.submitList(categoryList)
        binding.rvCategory.adapter = category
        binding.rvCategory.set3DItem(true)
        binding.rvCategory.setAlpha(true)
    }

    private fun onClickCategory(categoryModel: Category) {
        val action =
            HomeDirections.actionHomeFragmentToProductsFragment(categoryModel.categoryName)
        findNavController().navigate(action)
    }
}