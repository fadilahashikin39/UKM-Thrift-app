package com.example.ukmthrift.screens.products

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.example.ukmthrift.R
import com.example.ukmthrift.databinding.FragmentProductsBinding
import com.example.ukmthrift.delegate.viewBinding
import com.example.ukmthrift.model.Product
import com.example.ukmthrift.utils.extension.back
import com.example.ukmthrift.utils.extension.gone
import com.example.ukmthrift.utils.extension.visible
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ProductsFragment : Fragment(R.layout.fragment_products) {

    private val binding by viewBinding(FragmentProductsBinding::bind)
    private val productAdapter by lazy { ProductsAdapter(onClickDetail = ::onClickDetail) }
    private val viewModel: ProductsViewModel by viewModels()
    private val args: ProductsFragmentArgs by navArgs()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val categoryType = args.category
        viewModel.getProduct(categoryType.lowercase())
        initObservers()

        with(binding) {

            productToolbar.apply {
                tvProductTitle.text = categoryType
                ibArrowBack.setOnClickListener {
                    Navigation.back(it)
                }
            }
            rvProduct.adapter = productAdapter
        }
    }

    private fun onClickDetail(product: Product) {
        val action =
            ProductsFragmentDirections.actionProductsFragmentToProductDetailFragment(
                product
            )
        findNavController().navigate(action)

    }

    private fun initObservers() {
        with(binding) {
            viewModel.categoryList.observe(viewLifecycleOwner) { productList ->
                productAdapter.submitList(productList)
            }

            viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
                if (isLoading) {
                    rvProduct.gone()
                    loadingLottie.visible()
                } else {
                    rvProduct.visible()
                    loadingLottie.gone()
                }
            }
        }
    }
}