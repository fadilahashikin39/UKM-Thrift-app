package com.example.ukmthrift.screens.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.ukmthrift.databinding.ItemCategoryBinding
import com.example.ukmthrift.model.Category
import com.example.ukmthrift.utils.diffutil.DiffUtilCallback
import com.example.ukmthrift.utils.extension.loadImage

class Category(private val onClickCategory: (Category) -> Unit) :
    ListAdapter<Category, Category.CategoryViewHolder>(
        DiffUtilCallback<Category>(
            itemsTheSame = { oldItem, newItem ->
                oldItem == newItem
            },
            contentsTheSame = { oldItem, newItem ->
                oldItem == newItem
            }
        )
    ) {

    inner class CategoryViewHolder(private var itemCategoryBinding: ItemCategoryBinding) :
        RecyclerView.ViewHolder(itemCategoryBinding.root) {

        fun bind(category: Category) {
            with(itemCategoryBinding) {
                ivCategories.loadImage(category.categoryImage)
                root.setOnClickListener {
                    onClickCategory(category)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val binding =
            ItemCategoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CategoryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) =
        holder.bind(currentList[position])

    override fun getItemCount() = currentList.size


}