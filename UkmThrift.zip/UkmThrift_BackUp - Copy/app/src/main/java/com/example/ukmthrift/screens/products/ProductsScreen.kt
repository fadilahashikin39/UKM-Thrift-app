package com.example.ukmthrift.screens.products

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.ukmthrift.R
import com.example.ukmthrift.databinding.ItemProductsBinding
import com.example.ukmthrift.model.Product
import com.example.ukmthrift.utils.diffutil.DiffUtilCallback
import com.example.ukmthrift.utils.extension.visible

class ProductsAdapter(private val onClickDetail: (Product) -> Unit) :
    ListAdapter<Product, ProductsAdapter.ProductsViewHolder>(
        DiffUtilCallback<Product>(
            itemsTheSame = { oldItem, newItem ->
                oldItem == newItem
            },
            contentsTheSame = { oldItem, newItem ->
                oldItem == newItem
            }
        )
    ) {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductsViewHolder {
        val binding =
            ItemProductsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProductsViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductsViewHolder, position: Int) {
        holder.bind(currentList[position])
    }

    inner class ProductsViewHolder(private var binding: ItemProductsBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(product: Product) {
            with(binding) {
                tvProductName.text = product.productTitle
                tvProductPrice.text =
                    itemView.context.getString(R.string.total_tl, product.productPrice)

                Glide.with(binding.ivProduct).load(product.img).into(binding.ivProduct)
                if (product.productCount.toInt() <= 3) {
                    tvProductCount.visible()
                    tvProductCount.text = itemView.context.getString(
                        R.string.left_in_stock, product.productCount
                    )// order soon
                }

                root.setOnClickListener {
                    onClickDetail(product)
                }

            }
        }
    }

    override fun getItemCount() = currentList.size

}